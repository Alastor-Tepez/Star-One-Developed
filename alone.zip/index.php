<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="Alone: A Jornada de Ely é um jogo de aventura e exploração ambientado em um mundo sombrio, mágico e repleto de mistérios. Você assume o papel de Ely, um jovem bruxo solitário que desperta em meio à escuridão sem respostas sobre o seu destino. Guiado apenas por uma luz mística, ele deve atravessar cenários perigosos, coletar itens antigos e enfrentar desafios ocultos que testam sua coragem, inteligência e poder arcano.

Ao longo da jornada, cada artefato encontrado possui um propósito maior. Ely está reunindo os componentes necessários para construir algo misterioso — uma criação envolta em segredos que mudará o rumo de sua história. Porém, a verdade por trás desse objetivo só será revelada no segundo estágio do jogo, onde novos perigos, habilidades e revelações aguardam.

Com uma atmosfera imersiva, trilha envolvente e narrativa progressiva, Alone: A Jornada de Ely entrega uma experiência única de sobrevivência na escuridão, exploração mágica e descoberta de segredos que vão além do que os olhos podem ver.">
    <title>ALONE • A JORNADA DE ELY</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #0c0e1d 0%, #1a1a2e 50%, #0f3460 100%);
            color: #e0e0ff;
            height: 100vh;
            overflow: hidden;
            position: relative;
        }

        /* Efeito de partículas de fundo */
        canvas#bg-particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -2;
        }

        .stars {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(white, rgba(255,255,255,.2) 2px, transparent 5px),
                radial-gradient(white, rgba(255,255,255,.15) 1px, transparent 3px),
                radial-gradient(rgba(255,255,255,.1), rgba(255,255,255,.05) 1px, transparent 2px);
            background-size: 500px 500px, 300px 300px, 150px 150px;
            background-position: 0 0, 50px 50px, 25px 25px;
            z-index: -1;
            opacity: 0.3;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 40px 20px;
            text-align: center;
            position: relative;
            z-index: 10;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .logo {
            font-family: 'Orbitron', sans-serif;
            font-size: 4.5rem;
            background: linear-gradient(45deg, #ffd700, #ff8c00, #ff4500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
            margin-bottom: 20px;
            letter-spacing: 3px;
            animation: pulse 2s infinite;
        }

        .subtitle {
            font-size: 1.4rem;
            color: #a0a0c0;
            margin-bottom: 50px;
            font-style: italic;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }

        .btn {
            display: block;
            width: 100%;
            padding: 18px;
            margin: 15px 0;
            background: linear-gradient(135deg, rgba(255,215,0,0.15), rgba(255,140,0,0.1));
            border: 2px solid #ffd700;
            border-radius: 50px;
            color: #ffd700;
            font-family: 'Orbitron', sans-serif;
            font-size: 1.2rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(255, 215, 0, 0.4);
            background: linear-gradient(135deg, rgba(255,215,0,0.25), rgba(255,140,0,0.2));
        }

        .btn:active {
            transform: translateY(1px);
        }

        .btn::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,215,0,0.3) 0%, transparent 70%);
            opacity: 0;
            transition: opacity 0.5s;
            pointer-events: none;
        }

        .btn:hover::after {
            opacity: 1;
        }

        .ely-character {
            width: 120px;
            height: 180px;
            margin: 0 auto 30px;
            position: relative;
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-15px); }
        }

        @keyframes pulse {
            0%, 100% { text-shadow: 0 0 20px rgba(255, 215, 0, 0.5); }
            50% { text-shadow: 0 0 35px rgba(255, 215, 0, 0.8); }
        }

        .version {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
            color: rgba(255, 255, 255, 0.3);
            font-size: 0.8rem;
            letter-spacing: 1px;
        }

        @media (max-width: 480px) {
            .logo {
                font-size: 3.2rem;
            }
            .subtitle {
                font-size: 1.1rem;
                padding: 0 15px;
            }
            .btn {
                padding: 16px;
                font-size: 1.1rem;
            }
            .ely-character {
                width: 90px;
                height: 135px;
            }
        }
    </style>
</head>
<body>
    <canvas id="bg-particles"></canvas>
    <div class="stars"></div>
    
    <div class="container">
        <div class="ely-character" id="ely-preview"></div>
        <h1 class="logo">ALONE</h1>
        <p class="subtitle">Sobreviva na escuridão. Encontre seu caminho.</p>
        
        <a href="login.html" class="btn">
            <i class="fas fa-sign-in-alt"></i> ENTRAR
        </a>
        <a href="register.html" class="btn">
            <i class="fas fa-user-plus"></i> REGISTRAR
        </a>
        
        <div class="version">ESTÁGIO 1 • v1.0</div>
    </div>

    <script>
        // Partículas de fundo
        const canvas = document.getElementById('bg-particles');
        const ctx = canvas.getContext('2d');
        
        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();
        
        class Particle {
            constructor() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 3 + 1;
                this.speedX = Math.random() * 1 - 0.5;
                this.speedY = Math.random() * 1 - 0.5;
                this.color = `rgba(255, 215, 0, ${Math.random() * 0.3 + 0.1})`;
            }
            
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                
                if (this.x > canvas.width || this.x < 0) this.speedX *= -1;
                if (this.y > canvas.height || this.y < 0) this.speedY *= -1;
            }
            
            draw() {
                ctx.fillStyle = this.color;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fill();
            }
        }
        
        const particles = [];
        for (let i = 0; i < 80; i++) {
            particles.push(new Particle());
        }
        
        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(particle => {
                particle.update();
                particle.draw();
            });
            
            requestAnimationFrame(animate);
        }
        
        animate();
        
        // Renderizar preview do personagem Ely
        function drawElyPreview() {
            const elyEl = document.getElementById('ely-preview');
            const previewCanvas = document.createElement('canvas');
            previewCanvas.width = 120;
            previewCanvas.height = 180;
            elyEl.appendChild(previewCanvas);
            
            const ctx = previewCanvas.getContext('2d');
            
            // Corpo
            ctx.fillStyle = '#8a6343'; // Pele
            ctx.beginPath();
            ctx.ellipse(60, 100, 25, 40, 0, 0, Math.PI * 2);
            ctx.fill();
            
            // Cabeça
            ctx.fillStyle = '#8a6343';
            ctx.beginPath();
            ctx.arc(60, 60, 28, 0, Math.PI * 2);
            ctx.fill();
            
            // Cabelo
            ctx.fillStyle = '#3a2a1a';
            ctx.beginPath();
            ctx.arc(60, 55, 32, Math.PI, 0, false);
            ctx.lineTo(60, 75);
            ctx.fill();
            
            // Olhos
            ctx.fillStyle = '#2a1a0a';
            ctx.beginPath();
            ctx.arc(50, 55, 6, 0, Math.PI * 2);
            ctx.arc(70, 55, 6, 0, Math.PI * 2);
            ctx.fill();
            
            // Pupila
            ctx.fillStyle = 'white';
            ctx.beginPath();
            ctx.arc(52, 53, 2, 0, Math.PI * 2);
            ctx.arc(72, 53, 2, 0, Math.PI * 2);
            ctx.fill();
            
            // Boca
            ctx.strokeStyle = '#2a1a0a';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(60, 68, 8, 0, Math.PI);
            ctx.stroke();
            
            // Roupas
            ctx.fillStyle = '#4a2a6a';
            ctx.fillRect(35, 100, 50, 60);
            
            // Capa
            ctx.fillStyle = 'rgba(30, 20, 50, 0.8)';
            ctx.beginPath();
            ctx.moveTo(35, 100);
            ctx.lineTo(20, 160);
            ctx.lineTo(100, 160);
            ctx.lineTo(85, 100);
            ctx.fill();
            
            // Lanterna
            ctx.fillStyle = '#ffd700';
            ctx.beginPath();
            ctx.arc(30, 120, 8, 0, Math.PI * 2);
            ctx.fill();
            
            // Brilho da lanterna
            const gradient = ctx.createRadialGradient(30, 120, 0, 30, 120, 25);
            gradient.addColorStop(0, 'rgba(255, 215, 0, 0.8)');
            gradient.addColorStop(1, 'rgba(255, 215, 0, 0)');
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(30, 120, 25, 0, Math.PI * 2);
            ctx.fill();
        }
        
        drawElyPreview();
    </script>
</body>
</html>