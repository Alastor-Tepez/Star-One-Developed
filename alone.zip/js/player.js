class Ely {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 45;
        this.height = 75;
        this.speed = 4;
        this.direction = 'right';
        this.frame = 0;
        this.animationTimer = 0;
        this.animationSpeed = 0.1;
        this.health = 100;
        this.lanternRadius = 80;
        this.lanternPulse = 0;
        this.isWalking = false;
    }
    
    update(keys, touch) {
        this.isWalking = false;
        
        // Movimento
        if (keys.ArrowLeft || keys.a || touch.left) {
            this.x -= this.speed;
            this.direction = 'left';
            this.isWalking = true;
        }
        if (keys.ArrowRight || keys.d || touch.right) {
            this.x += this.speed;
            this.direction = 'right';
            this.isWalking = true;
        }
        if (keys.ArrowUp || keys.w || touch.up) {
            this.y -= this.speed;
            this.isWalking = true;
        }
        if (keys.ArrowDown || keys.s || touch.down) {
            this.y += this.speed;
            this.isWalking = true;
        }
        
        // Animação
        this.animationTimer += this.animationSpeed;
        if (this.animationTimer >= 1) {
            this.animationTimer = 0;
            this.frame = (this.frame + 1) % 4;
        }
        
        // Pulsação da lanterna
        this.lanternPulse = Math.sin(Date.now() / 300) * 5;
        
        // Limites do canvas
        this.x = Math.max(20, Math.min(game.canvas.width - this.width - 20, this.x));
        this.y = Math.max(20, Math.min(game.canvas.height - this.height - 20, this.y));
    }
    
    draw(ctx) {
        // Sombra suave
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 15;
        ctx.shadowOffsetX = 3;
        ctx.shadowOffsetY = 5;
        
        // Corpo principal
        ctx.fillStyle = '#8a6343'; // Tom de pele realista
        ctx.beginPath();
        ctx.ellipse(this.x + this.width/2, this.y + 45, 18, 30, 0, 0, Math.PI * 2);
        ctx.fill();
        
        // Cabeça
        ctx.fillStyle = '#8a6343';
        ctx.beginPath();
        ctx.arc(this.x + this.width/2, this.y + 20, 20, 0, Math.PI * 2);
        ctx.fill();
        
        // Cabelo (estilo selvagem)
        ctx.fillStyle = '#2a1a0a';
        ctx.beginPath();
        if (this.direction === 'right') {
            ctx.moveTo(this.x + 5, this.y + 10);
            ctx.quadraticCurveTo(this.x - 10, this.y - 5, this.x + 15, this.y - 15);
            ctx.quadraticCurveTo(this.x + 35, this.y - 25, this.x + 45, this.y - 15);
            ctx.quadraticCurveTo(this.x + 65, this.y - 5, this.x + 55, this.y + 15);
        } else {
            ctx.moveTo(this.x + this.width - 5, this.y + 10);
            ctx.quadraticCurveTo(this.x + this.width + 10, this.y - 5, this.x + this.width - 15, this.y - 15);
            ctx.quadraticCurveTo(this.x + this.width - 35, this.y - 25, this.x + this.width - 45, this.y - 15);
            ctx.quadraticCurveTo(this.x + this.width - 65, this.y - 5, this.x + this.width - 55, this.y + 15);
        }
        ctx.lineTo(this.x + this.width - 15, this.y + 15);
        ctx.lineTo(this.x + 15, this.y + 15);
        ctx.fill();
        
        // Olhos expressivos
        ctx.fillStyle = '#1a0a00';
        if (this.direction === 'right') {
            ctx.beginPath();
            ctx.ellipse(this.x + 32, this.y + 18, 7, 9, 0, 0, Math.PI * 2);
            ctx.ellipse(this.x + 48, this.y + 18, 6, 8, 0, 0, Math.PI * 2);
            ctx.fill();
        } else {
            ctx.beginPath();
            ctx.ellipse(this.x + 13, this.y + 18, 6, 8, 0, 0, Math.PI * 2);
            ctx.ellipse(this.x + 28, this.y + 18, 7, 9, 0, 0, Math.PI * 2);
            ctx.fill();
        }
        
        // Reflexo nos olhos (destaque)
        ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
        ctx.beginPath();
        ctx.arc(this.x + (this.direction === 'right' ? 34 : 15), this.y + 16, 2, 0, Math.PI * 2);
        ctx.fill();
        
        // Boca (expressão determinada)
        ctx.strokeStyle = '#1a0a00';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(this.x + this.width/2, this.y + 28, 6, 0.1 * Math.PI, 0.9 * Math.PI);
        ctx.stroke();
        
        // Roupas rasgadas (sobrevivente)
        ctx.fillStyle = '#3a2555'; // Roxo escuro
        ctx.fillRect(this.x + 10, this.y + 45, 25, 35);
        
        // Capa esfarrapada
        ctx.fillStyle = 'rgba(20, 15, 35, 0.9)';
        ctx.beginPath();
        ctx.moveTo(this.x + 5, this.y + 45);
        ctx.lineTo(this.x - 5, this.y + 85);
        ctx.lineTo(this.x + this.width + 5, this.y + 85);
        ctx.lineTo(this.x + this.width - 5, this.y + 45);
        ctx.fill();
        
        // Lanterna (elemento-chave)
        const lanternX = this.x + (this.direction === 'right' ? 5 : this.width - 5);
        const lanternY = this.y + 35;
        
        // Corpo da lanterna
        ctx.fillStyle = '#555';
        ctx.fillRect(lanternX - 8, lanternY - 15, 16, 30);
        
        // Vidro da lanterna
        ctx.fillStyle = '#ffd700';
        ctx.beginPath();
        ctx.arc(lanternX, lanternY, 10, 0, Math.PI * 2);
        ctx.fill();
        
        // Brilho da lanterna (efeito de luz realista)
        ctx.shadowBlur = 40;
        ctx.shadowColor = `rgba(255, 215, 0, ${0.7 + this.lanternPulse * 0.1})`;
        ctx.fillStyle = `rgba(255, 215, 0, ${0.3 + this.lanternPulse * 0.05})`;
        ctx.beginPath();
        ctx.arc(lanternX, lanternY, this.lanternRadius + this.lanternPulse, 0, Math.PI * 2);
        ctx.fill();
        
        // Reset shadow
        ctx.shadowBlur = 0;
        ctx.shadowColor = 'transparent';
        
        // Nome "Ely" flutuante
        ctx.fillStyle = 'rgba(255, 215, 0, 0.9)';
        ctx.font = '14px Orbitron, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('ELY', this.x + this.width/2, this.y - 15);
    }
    
    getLanternPosition() {
        return {
            x: this.x + (this.direction === 'right' ? 5 : this.width - 5),
            y: this.y + 35
        };
    }
}