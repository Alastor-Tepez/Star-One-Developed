class Game {
    constructor() {
        this.canvas = document.getElementById('game-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.width = window.innerWidth;
        this.height = window.innerHeight;
        this.ely = new Ely(this.width * 0.2, this.height / 2);
        this.monsters = [];
        this.items = [];
        this.river = {
            y: this.height / 2,
            width: 120,
            flow: 0
        };
        this.keys = {};
        this.touch = {
            left: false,
            right: false,
            up: false,
            down: false
        };
        this.mission = 1;
        this.score = 0;
        this.stars = 0;
        this.apples = 0;
        this.wood = 0;
        this.gameOver = false;
        this.victory = false;
        this.particles = [];
        this.fog = [];
        this.init();
    }
    
    init() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        
        // Eventos de teclado
        window.addEventListener('keydown', (e) => this.keys[e.key] = true);
        window.addEventListener('keyup', (e) => this.keys[e.key] = false);
        
        // Eventos touch para mobile
        this.setupTouchControls();
        
        // Iniciar missão
        this.startMission(this.mission);
        
        // Iniciar loop
        this.gameLoop();
    }
    
    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
        this.width = this.canvas.width;
        this.height = this.canvas.height;
        this.river.y = this.height / 2;
        
        // Reposicionar Ely se necessário
        if (this.ely) {
            this.ely.x = Math.min(this.ely.x, this.width - this.ely.width - 20);
            this.ely.y = Math.min(this.ely.y, this.height - this.ely.height - 20);
        }
    }
    
    setupTouchControls() {
        const controls = document.getElementById('touch-controls');
        if (!controls) return;
        
        // Função para evitar o erro de touchstart
        const handleTouchStart = (e, direction) => {
            // Verificar se o evento é cancelável antes de prevenir
            if (e.cancelable) {
                e.preventDefault();
            }
            this.touch[direction] = true;
        };
        
        const handleTouchEnd = (e, direction) => {
            if (e.cancelable) {
                e.preventDefault();
            }
            this.touch[direction] = false;
        };
        
        // Setas de controle
        const directions = ['up', 'down', 'left', 'right'];
        directions.forEach(dir => {
            const btn = controls.querySelector(`.btn-${dir}`);
            if (btn) {
                // Eventos touch
                btn.addEventListener('touchstart', (e) => handleTouchStart(e, dir), { passive: false });
                btn.addEventListener('touchend', (e) => handleTouchEnd(e, dir), { passive: false });
                btn.addEventListener('touchcancel', (e) => handleTouchEnd(e, dir), { passive: false });
                
                // Eventos mouse (para desktop)
                btn.addEventListener('mousedown', (e) => {
                    e.preventDefault();
                    this.touch[dir] = true;
                });
                btn.addEventListener('mouseup', (e) => {
                    e.preventDefault();
                    this.touch[dir] = false;
                });
                btn.addEventListener('mouseleave', (e) => {
                    this.touch[dir] = false;
                });
            }
        });
    }
    
    startMission(missionNum) {
        this.mission = missionNum;
        this.monsters = [];
        this.items = [];
        this.particles = [];
        this.fog = [];
        
        // Resetar posição
        this.ely.x = this.width * 0.2;
        this.ely.y = this.height / 2;
        this.ely.health = 100;
        
        // Criar névoa atmosférica
        for (let i = 0; i < 15; i++) {
            this.fog.push({
                x: Math.random() * this.width,
                y: Math.random() * this.height,
                size: Math.random() * 80 + 40,
                speed: Math.random() * 0.3 + 0.1,
                opacity: Math.random() * 0.15 + 0.05
            });
        }
        
        switch(missionNum) {
            case 1:
                this.spawnMonsters(6);
                this.updateMissionUI('ATRAVESSAR O RIO', 'Fuja dos monstros e cruze o rio perigoso');
                break;
            case 2:
                this.spawnItems('apple', 3);
                this.spawnMonsters(4);
                this.updateMissionUI('COLETAR MAÇÃS', 'Encontre 3 maçãs douradas na floresta escura');
                break;
            case 3:
                this.spawnItems('wood', 5);
                this.spawnMonsters(5);
                this.updateMissionUI('COLETAR MADEIRA', 'Colete 5 pedaços de madeira para construir');
                break;
            case 4:
                this.spawnMonsters(8);
                this.updateMissionUI('RETORNAR AO RIO', 'Volte para o outro lado do rio com seus recursos');
                break;
            case 5:
                this.victory = true;
                this.showVictoryScreen();
                return;
        }
        
        this.gameOver = false;
    }
    
    spawnMonsters(count) {
        for (let i = 0; i < count; i++) {
            const side = Math.random() > 0.5 ? 'left' : 'right';
            const x = side === 'left' ? -50 : this.width + 50;
            const y = Math.random() * this.height;
            
            this.monsters.push({
                x: x,
                y: y,
                width: 50,
                height: 60,
                speed: 1.5 + Math.random() * 1.5,
                targetX: this.width / 2,
                targetY: Math.random() * this.height,
                type: Math.floor(Math.random() * 3),
                frame: 0,
                timer: 0,
                side: side
            });
        }
    }
    
    spawnItems(type, count) {
        for (let i = 0; i < count; i++) {
            this.items.push({
                x: 150 + Math.random() * (this.width - 300),
                y: 100 + Math.random() * (this.height - 200),
                width: 35,
                height: 35,
                type: type,
                float: 0,
                collected: false
            });
        }
    }
    
    updateMissionUI(title, description) {
        document.getElementById('mission-title').textContent = title;
        document.getElementById('mission-desc').textContent = description;
        document.getElementById('mission-counter').textContent = 
            this.mission === 2 ? `${this.apples}/3` : 
            this.mission === 3 ? `${this.wood}/5` : '';
    }
    
    gameLoop() {
        if (this.gameOver || this.victory) {
            requestAnimationFrame(() => this.gameLoop());
            return;
        }
        
        // Limpar canvas com gradiente atmosférico
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.height);
        gradient.addColorStop(0, '#0a0a1a');
        gradient.addColorStop(0.5, '#0f1a3a');
        gradient.addColorStop(1, '#0a0f2a');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.width, this.height);
        
        // Atualizar e desenhar elementos
        this.updateRiver();
        this.drawRiver();
        this.updateFog();
        this.drawFog();
        this.ely.update(this.keys, this.touch);
        this.updateMonsters();
        this.updateItems();
        this.updateParticles();
        
        // Desenhar elementos
        this.drawItems();
        this.drawMonsters();
        this.ely.draw(this.ctx);
        this.drawParticles();
        this.drawUI();
        
        // Verificar colisões
        this.checkCollisions();
        this.checkMissionComplete();
        
        requestAnimationFrame(() => this.gameLoop());
    }
    
    updateRiver() {
        this.river.flow += 0.02;
    }
    
    drawRiver() {
        // Base do rio
        const gradient = this.ctx.createLinearGradient(0, this.river.y - this.river.width/2, 0, this.river.y + this.river.width/2);
        gradient.addColorStop(0, 'rgba(0, 30, 80, 0.7)');
        gradient.addColorStop(0.5, 'rgba(0, 50, 120, 0.9)');
        gradient.addColorStop(1, 'rgba(0, 30, 80, 0.7)');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, this.river.y - this.river.width/2, this.width, this.river.width);
        
        // Ondas animadas
        this.ctx.strokeStyle = 'rgba(100, 180, 255, 0.4)';
        this.ctx.lineWidth = 2;
        
        for (let i = 0; i < this.width; i += 30) {
            const waveOffset = Math.sin((i + this.river.flow * 200) * 0.1) * 8;
            this.ctx.beginPath();
            this.ctx.moveTo(i, this.river.y - this.river.width/2 + 20 + waveOffset);
            this.ctx.quadraticCurveTo(
                i + 15, this.river.y - this.river.width/2 + 10 + waveOffset,
                i + 30, this.river.y - this.river.width/2 + 20 + waveOffset
            );
            this.ctx.stroke();
        }
        
        // Reflexo da lanterna na água
        const lantern = this.ely.getLanternPosition();
        if (Math.abs(lantern.y - this.river.y) < this.river.width/2 + 50) {
            const distance = Math.abs(lantern.y - this.river.y);
            const intensity = Math.max(0, 1 - distance / 100);
            
            this.ctx.save();
            this.ctx.globalAlpha = 0.3 * intensity;
            this.ctx.fillStyle = `rgba(255, 215, 0, ${0.4 * intensity})`;
            
            // Reflexo distorcido
            for (let i = 0; i < 5; i++) {
                const offset = Math.sin(Date.now() / 200 + i) * 15;
                this.ctx.beginPath();
                this.ctx.arc(lantern.x + offset, this.river.y + (lantern.y - this.river.y) + 10, 
                           30 * intensity, 0, Math.PI * 2);
                this.ctx.fill();
            }
            
            this.ctx.restore();
        }
    }
    
    updateFog() {
        this.fog.forEach(fog => {
            fog.x += fog.speed;
            if (fog.x > this.width + fog.size) {
                fog.x = -fog.size;
                fog.y = Math.random() * this.height;
            }
        });
    }
    
    drawFog() {
        this.fog.forEach(fog => {
            this.ctx.save();
            this.ctx.globalAlpha = fog.opacity;
            this.ctx.fillStyle = 'rgba(150, 180, 220, 0.1)';
            this.ctx.beginPath();
            this.ctx.arc(fog.x, fog.y, fog.size, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.restore();
        });
    }
    
    updateMonsters() {
        this.monsters.forEach(monster => {
            // Movimento em direção ao jogador com variação
            const dx = this.ely.x - monster.x;
            const dy = this.ely.y - monster.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            if (dist > 50) {
                monster.x += (dx / dist) * monster.speed;
                monster.y += (dy / dist) * monster.speed;
            }
            
            // Animação
            monster.timer += 0.05;
            monster.frame = Math.floor(monster.timer) % 4;
            
            // Manter dentro dos limites
            monster.x = Math.max(0, Math.min(this.width - monster.width, monster.x));
            monster.y = Math.max(0, Math.min(this.height - monster.height, monster.y));
        });
    }
    
    drawMonsters() {
        this.monsters.forEach(monster => {
            this.ctx.save();
            
            // Sombra
            this.ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
            this.ctx.shadowBlur = 15;
            this.ctx.shadowOffsetX = 3;
            this.ctx.shadowOffsetY = 5;
            
            // Corpo do monstro (criatura das sombras)
            this.ctx.fillStyle = '#4a0a0a';
            this.ctx.beginPath();
            this.ctx.ellipse(monster.x + 25, monster.y + 35, 22, 30, 0, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Cabeça deformada
            this.ctx.fillStyle = '#3a0505';
            this.ctx.beginPath();
            this.ctx.arc(monster.x + 25, monster.y + 15, 18, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Olhos brilhantes (ameaçadores)
            this.ctx.fillStyle = '#ff3333';
            this.ctx.beginPath();
            this.ctx.arc(monster.x + 18, monster.y + 12, 6, 0, Math.PI * 2);
            this.ctx.arc(monster.x + 32, monster.y + 12, 6, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Detalhes dos olhos
            this.ctx.fillStyle = 'white';
            this.ctx.beginPath();
            this.ctx.arc(monster.x + 20, monster.y + 10, 2, 0, Math.PI * 2);
            this.ctx.arc(monster.x + 34, monster.y + 10, 2, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Garras
            this.ctx.fillStyle = '#2a0000';
            for (let i = 0; i < 4; i++) {
                this.ctx.beginPath();
                this.ctx.ellipse(monster.x + 10 + i * 10, monster.y + 60, 4, 8, 0.3, 0, Math.PI * 2);
                this.ctx.fill();
            }
            
            // Efeito de fumaça/sombra ao redor
            this.ctx.shadowBlur = 25;
            this.ctx.shadowColor = 'rgba(70, 10, 10, 0.7)';
            this.ctx.fillStyle = 'rgba(50, 5, 5, 0.3)';
            this.ctx.beginPath();
            this.ctx.arc(monster.x + 25, monster.y + 40, 30, 0, Math.PI * 2);
            this.ctx.fill();
            
            this.ctx.restore();
            
            // Nome do monstro
            this.ctx.fillStyle = 'rgba(255, 50, 50, 0.8)';
            this.ctx.font = '10px Orbitron, sans-serif';
            this.ctx.textAlign = 'center';
            this.ctx.fillText('SOMBRA', monster.x + 25, monster.y - 10);
        });
    }
    
    updateItems() {
        this.items.forEach(item => {
            if (!item.collected) {
                // Efeito de flutuação suave
                item.float = Math.sin(Date.now() / 300 + item.x * 0.01) * 5;
                
                // Brilho pulsante para itens
                if (item.type === 'apple') {
                    item.glow = Math.sin(Date.now() / 200) * 0.2 + 0.8;
                }
            }
        });
    }
    
    drawItems() {
        this.items.forEach(item => {
            if (item.collected) return;
            
            this.ctx.save();
            this.ctx.translate(item.x, item.y + item.float);
            
            if (item.type === 'apple') {
                // Maçã dourada brilhante
                const glow = item.glow || 1;
                
                // Brilho externo
                this.ctx.shadowColor = `rgba(255, 215, 0, ${0.6 * glow})`;
                this.ctx.shadowBlur = 20;
                
                // Corpo da maçã
                this.ctx.fillStyle = `rgba(255, 140, 0, ${0.9 * glow})`;
                this.ctx.beginPath();
                this.ctx.arc(17.5, 17.5, 15, 0, Math.PI * 2);
                this.ctx.fill();
                
                // Reflexo
                this.ctx.fillStyle = `rgba(255, 255, 255, ${0.5 * glow})`;
                this.ctx.beginPath();
                this.ctx.ellipse(12, 12, 4, 6, -0.3, 0, Math.PI * 2);
                this.ctx.fill();
                
                // Cabo
                this.ctx.fillStyle = '#8b4513';
                this.ctx.fillRect(16, 5, 3, 8);
                
                // Folha
                this.ctx.fillStyle = `rgba(50, 150, 50, ${glow})`;
                this.ctx.beginPath();
                this.ctx.ellipse(17.5, 8, 5, 3, 0.5, 0, Math.PI * 2);
                this.ctx.fill();
            } 
            else if (item.type === 'wood') {
                // Madeira texturizada
                this.ctx.fillStyle = '#8b4513';
                this.ctx.fillRect(5, 5, 25, 25);
                
                // Detalhes da madeira
                this.ctx.fillStyle = '#a0522d';
                for (let i = 0; i < 3; i++) {
                    this.ctx.fillRect(8 + i * 6, 10, 2, 15);
                }
                
                // Nó da madeira
                this.ctx.fillStyle = '#5a301a';
                this.ctx.beginPath();
                this.ctx.arc(17.5, 17.5, 4, 0, Math.PI * 2);
                this.ctx.fill();
            }
            
            this.ctx.restore();
        });
    }
    
    updateParticles() {
        // Partículas de poeira/luz
        if (Math.random() > 0.95 && this.particles.length < 100) {
            const lantern = this.ely.getLanternPosition();
            this.particles.push({
                x: lantern.x + (Math.random() - 0.5) * 20,
                y: lantern.y + (Math.random() - 0.5) * 20,
                size: Math.random() * 3 + 1,
                speedX: (Math.random() - 0.5) * 1.5,
                speedY: (Math.random() - 0.7) * 1.5,
                life: 100,
                color: `rgba(255, 215, 0, ${Math.random() * 0.7 + 0.3})`
            });
        }
        
        // Atualizar partículas existentes
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.speedX;
            p.y += p.speedY;
            p.life -= 1.5;
            p.size *= 0.99;
            
            if (p.life <= 0 || p.size < 0.5) {
                this.particles.splice(i, 1);
            }
        }
    }
    
    drawParticles() {
        this.particles.forEach(p => {
            this.ctx.fillStyle = p.color;
            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            this.ctx.fill();
        });
    }
    
    drawUI() {
        // HUD semi-transparente
        this.ctx.fillStyle = 'rgba(10, 15, 30, 0.85)';
        this.ctx.fillRect(20, 20, 280, 140);
        this.ctx.strokeStyle = '#ffd700';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(20, 20, 280, 140);
        
        // Estilo de texto HUD
        this.ctx.font = '16px Orbitron, sans-serif';
        this.ctx.fillStyle = '#ffd700';
        this.ctx.textAlign = 'left';
        
        // Vida
        this.ctx.fillText('VIDA', 40, 50);
        this.ctx.fillStyle = '#ff3333';
        this.ctx.fillRect(40, 60, 200 * (this.ely.health / 100), 12);
        this.ctx.strokeStyle = '#ffffff';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(40, 60, 200, 12);
        this.ctx.fillStyle = '#ffd700';
        this.ctx.fillText(`${this.ely.health}%`, 250, 70);
        
        // Missão
        this.ctx.fillText('MISSÃO', 40, 100);
        this.ctx.fillStyle = '#a0a0ff';
        this.ctx.fillText(`#${this.mission}`, 40, 125);
        
        // Coletáveis
        if (this.mission === 2 || this.mission === 3) {
            this.ctx.fillText('COLETADOS', 150, 100);
            this.ctx.fillStyle = this.mission === 2 ? '#ffaa00' : '#8b4513';
            this.ctx.fillText(
                this.mission === 2 ? `${this.apples}/3` : `${this.wood}/5`,
                150, 125
            );
        }
        
        // Estrelas
        this.ctx.fillStyle = '#ffd700';
        this.ctx.fillText(`ESTRELAS: ${this.stars}`, 40, 155);
    }
    
    checkCollisions() {
        // Colisão com monstros
        for (let i = this.monsters.length - 1; i >= 0; i--) {
            const m = this.monsters[i];
            const dx = (this.ely.x + this.ely.width/2) - (m.x + m.width/2);
            const dy = (this.ely.y + this.ely.height/2) - (m.y + m.height/2);
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 60) {
                this.ely.health -= 0.8;
                if (this.ely.health <= 0) {
                    this.gameOver = true;
                    this.showGameOver();
                }
            }
        }
        
        // Colisão com itens
        this.items.forEach(item => {
            if (item.collected) return;
            
            const dx = (this.ely.x + this.ely.width/2) - (item.x + item.width/2);
            const dy = (this.ely.y + this.ely.height/2) - (item.y + item.height/2 + item.float);
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 40) {
                item.collected = true;
                
                // Efeito de coleta
                for (let i = 0; i < 15; i++) {
                    this.particles.push({
                        x: item.x + item.width/2,
                        y: item.y + item.height/2,
                        size: Math.random() * 4 + 2,
                        speedX: (Math.random() - 0.5) * 4,
                        speedY: (Math.random() - 0.5) * 4,
                        life: 80,
                        color: item.type === 'apple' ? 
                               `rgba(255, 215, 0, ${Math.random() * 0.8 + 0.2})` :
                               `rgba(139, 69, 19, ${Math.random() * 0.8 + 0.2})`
                    });
                }
                
                if (item.type === 'apple') {
                    this.apples++;
                    this.stars += 5;
                } else if (item.type === 'wood') {
                    this.wood++;
                    this.stars += 3;
                }
            }
        });
    }
    
    checkMissionComplete() {
        switch(this.mission) {
            case 1: // Atravessar rio
                if (this.ely.y > this.river.y + this.river.width/2 + 30) {
                    this.completeMission();
                }
                break;
            case 2: // Coletar 3 maçãs
                if (this.apples >= 3) {
                    this.completeMission();
                }
                break;
            case 3: // Coletar 5 madeiras
                if (this.wood >= 5) {
                    this.completeMission();
                }
                break;
            case 4: // Voltar ao rio
                if (this.ely.y < this.river.y - this.river.width/2 - 30) {
                    this.completeMission();
                }
                break;
        }
    }
    
    completeMission() {
        this.stars += 20;
        this.mission++;
        this.showMissionComplete();
    }
    
    showGameOver() {
        document.getElementById('game-over-screen').classList.add('active');
    }
    
    showVictoryScreen() {
        document.getElementById('victory-screen').classList.add('active');
    }
    
    showMissionComplete() {
        const screen = document.getElementById('mission-complete-screen');
        screen.querySelector('.mission-number').textContent = this.mission - 1;
        screen.querySelector('.stars-earned').textContent = this.stars;
        screen.classList.add('active');
    }
    
    restartMission() {
        document.getElementById('game-over-screen').classList.remove('active');
        this.startMission(this.mission);
    }
    
    nextMission() {
        document.getElementById('mission-complete-screen').classList.remove('active');
        this.startMission(this.mission);
    }
}

// Iniciar jogo quando carregar
document.addEventListener('DOMContentLoaded', () => {
    // Inicializar apenas se estiver na página do jogo
    if (document.getElementById('game-canvas')) {
        window.game = new Game();
    }
});