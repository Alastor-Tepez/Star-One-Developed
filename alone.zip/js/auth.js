class AuthManager {
    constructor() {
        this.apiUrl = 'php/auth.php';
        this.isLoggedIn = false;
        this.playerData = null;
        this.debugMode = true; // Ativar para ver logs detalhados no console
    }

    log(...args) {
        if (this.debugMode) {
            console.log('[AUTH DEBUG]', ...args);
        }
    }

    async register(username, email, password, confirmPassword) {
        this.log('Registrando usuário:', { username, email });
        
        try {
            const formData = new FormData();
            formData.append('action', 'register');
            formData.append('username', username.trim());
            formData.append('email', email.trim());
            formData.append('password', password);
            formData.append('confirm_password', confirmPassword);

            const response = await fetch(this.apiUrl, {
                method: 'POST',
                body: formData,
                credentials: 'include' // IMPORTANTE: enviar cookies/session
            });

            const data = await response.json();
            this.log('Resposta registro:', data);

            if (data.success) {
                this.showNotification('✅ Registro realizado! Redirecionando...', 'success');
                this.isLoggedIn = true;
                this.playerData = data.data;
                localStorage.setItem('playerData', JSON.stringify(data.data));
                
                setTimeout(() => {
                    if (data.data.redirect) {
                        window.location.href = data.data.redirect;
                    } else {
                        window.location.href = 'game.html';
                    }
                }, 1500);
            } else {
                this.showNotification('❌ ' + (data.message || 'Erro desconhecido'), 'error');
                if (this.debugMode && data.debug) {
                    console.error('Detalhes do erro:', data.debug);
                }
            }

            return data;
        } catch (error) {
            console.error('Erro no registro:', error);
            this.showNotification('❌ Erro de conexão: ' + error.message, 'error');
            return { success: false, message: error.message };
        }
    }

    async login(username, password) {
        this.log('Fazendo login:', { username });
        
        try {
            const formData = new FormData();
            formData.append('action', 'login');
            formData.append('username', username.trim());
            formData.append('password', password);

            const response = await fetch(this.apiUrl, {
                method: 'POST',
                body: formData,
                credentials: 'include' // IMPORTANTE
            });

            const data = await response.json();
            this.log('Resposta login:', data);

            if (data.success) {
                this.showNotification('✅ Login bem-sucedido!', 'success');
                this.isLoggedIn = true;
                this.playerData = data.data;
                localStorage.setItem('playerData', JSON.stringify(data.data));
                
                setTimeout(() => {
                    if (data.data.redirect) {
                        window.location.href = data.data.redirect;
                    } else {
                        window.location.href = 'game.html';
                    }
                }, 1000);
            } else {
                this.showNotification('❌ ' + (data.message || 'Credenciais inválidas'), 'error');
                if (this.debugMode && data.debug) {
                    console.warn('Detalhes do erro de login:', data.debug);
                }
            }

            return data;
        } catch (error) {
            console.error('Erro no login:', error);
            this.showNotification('❌ Erro: ' + error.message + '. Verifique sua conexão.', 'error');
            return { success: false, message: error.message };
        }
    }

    async logout() {
        try {
            const formData = new FormData();
            formData.append('action', 'logout');

            await fetch(this.apiUrl, {
                method: 'POST',
                body: formData,
                credentials: 'include'
            });

            this.isLoggedIn = false;
            this.playerData = null;
            localStorage.removeItem('playerData');
            sessionStorage.clear();

            this.showNotification('✅ Logout realizado!', 'success');
            
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);
        } catch (error) {
            console.error('Erro no logout:', error);
            window.location.href = 'index.html'; // Forçar redirect mesmo com erro
        }
    }

    async checkSession() {
        try {
            const formData = new FormData();
            formData.append('action', 'check_session');

            const response = await fetch(this.apiUrl, {
                method: 'POST',
                body: formData,
                credentials: 'include'
            });

            const data = await response.json();
            this.log('Verificação de sessão:', data);

            if (data.success && data.data?.player_id) {
                this.isLoggedIn = true;
                this.playerData = data.data;
                return true;
            } else {
                this.isLoggedIn = false;
                this.playerData = null;
                return false;
            }
        } catch (error) {
            console.warn('Erro na verificação de sessão:', error);
            return false;
        }
    }

    showNotification(message, type = 'info') {
        // Remover notificação anterior
        let existing = document.getElementById('auth-notification');
        if (existing) existing.remove();

        // Criar nova
        const notification = document.createElement('div');
        notification.id = 'auth-notification';
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div style="display:flex;align-items:center;gap:12px;">
                <span style="font-size:1.4em">${this.getIcon(type)}</span>
                <span style="flex:1">${message}</span>
                <button style="background:none;border:none;color:#ffd700;font-size:1.5em;cursor:pointer;padding:0 10px;" 
                        onclick="this.parentElement.parentElement.remove()">&times;</button>
            </div>
        `;
        notification.style.cssText = `
            position:fixed;top:20px;right:20px;background:rgba(30,35,60,0.95);border:2px solid #ffd700;
            border-radius:10px;padding:15px 25px;color:#ffd700;font-family:Montserrat,sans-serif;font-size:1.05rem;
            box-shadow:0 5px 20px rgba(0,0,0,0.5);z-index:10000;animation:slideIn 0.4s ease;
        `;

        document.body.appendChild(notification);

        // Auto-remover
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => {
                if (notification.parentNode) notification.remove();
            }, 300);
        }, 5000);
    }

    getIcon(type) {
        return ({success:'✅',error:'❌',info:'ℹ️',warning:'⚠️'})[type] || 'ℹ️';
    }

    // Método de conveniência para forms
    setupFormHandlers() {
        document.addEventListener('DOMContentLoaded', () => {
            // Formulário de registro
            const regForm = document.getElementById('register-form');
            if (regForm) {
                regForm.addEventListener('submit', async (e) => {
                    e.preventDefault();
                    const username = document.getElementById('reg-username')?.value || '';
                    const email = document.getElementById('reg-email')?.value || '';
                    const password = document.getElementById('reg-password')?.value || '';
                    const confirm = document.getElementById('reg-confirm-password')?.value || 
                                   document.getElementById('confirm_password')?.value || '';
                    
                    await this.register(username, email, password, confirm);
                });
            }

            // Formulário de login
            const loginForm = document.getElementById('login-form');
            if (loginForm) {
                loginForm.addEventListener('submit', async (e) => {
                    e.preventDefault();
                    const username = document.getElementById('login-username')?.value || 
                                    document.getElementById('username')?.value || '';
                    const password = document.getElementById('login-password')?.value || 
                                    document.getElementById('password')?.value || '';
                    
                    await this.login(username, password);
                });
            }

            // Botão de logout
            const logoutBtn = document.getElementById('logout-btn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.logout();
                });
            }

            // Verificar sessão ao carregar página de jogo
            if (window.location.pathname.includes('game.html')) {
                this.checkSession().then(isValid => {
                    if (!isValid) {
                        this.showNotification('⚠️ Sessão expirada. Faça login novamente.', 'warning');
                        setTimeout(() => {
                            window.location.href = 'login.html';
                        }, 2000);
                    }
                });
            }
        });
    }
}

// Inicializar globalmente
const authManager = new AuthManager();
authManager.setupFormHandlers();

// Ativar debug no console para desenvolvimento
if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
    console.log('%c🎮 ALONE - Sistema de Autenticação Carregado', 
                'color:#ffd700;font-weight:bold;font-size:16px;');
    console.log('AuthManager disponível globalmente como "authManager"');
}