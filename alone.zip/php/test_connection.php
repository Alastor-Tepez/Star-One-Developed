<?php
header('Content-Type: application/json');

// Testar se PHP está funcionando
$response = [
    'php_working' => true,
    'php_version' => phpversion(),
    'session_support' => extension_loaded('session'),
    'mysqli_support' => extension_loaded('mysqli'),
    'post_data' => $_POST,
    'get_data' => $_GET,
    'server_info' => [
        'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'N/A',
        'script_filename' => __FILE__,
        'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'N/A'
    ]
];

echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>