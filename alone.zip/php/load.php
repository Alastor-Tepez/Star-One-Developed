<?php
require_once 'config.php';

// Verificar se usuário está logado
if (!isLoggedIn()) {
    jsonResponse(false, 'Não autenticado');
}

try {
    $player_id = $_SESSION['player_id'];
    $conn = getDBConnection();
    
    if (!$conn) {
        jsonResponse(false, 'Erro ao conectar ao banco de dados');
    }

    // Obter progresso do jogador
    $stmt = $conn->prepare("
        SELECT 
            pp.current_level,
            pp.health,
            pp.stars_earned,
            pp.apples_collected,
            pp.wood_collected,
            pp.completed_missions,
            p.username,
            p.email,
            p.created_at,
            p.last_login
        FROM player_progress pp
        INNER JOIN players p ON pp.player_id = p.id
        WHERE pp.player_id = ?
    ");
    $stmt->bind_param("i", $player_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        jsonResponse(false, 'Progresso não encontrado');
    }

    $progress = $result->fetch_assoc();
    $stmt->close();

    // Obter estatísticas gerais
    $stmt = $conn->prepare("
        SELECT 
            SUM(time_played) as total_time,
            SUM(monsters_avoided) as total_monsters,
            SUM(items_collected) as total_items,
            SUM(deaths) as total_deaths,
            COUNT(*) as total_sessions
        FROM game_stats 
        WHERE player_id = ?
    ");
    $stmt->bind_param("i", $player_id);
    $stmt->execute();
    $stats = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Obter ranking (posição do jogador)
    $stmt = $conn->prepare("
        SELECT COUNT(*) + 1 as ranking
        FROM player_progress
        WHERE stars_earned > (
            SELECT stars_earned FROM player_progress WHERE player_id = ?
        )
    ");
    $stmt->bind_param("i", $player_id);
    $stmt->execute();
    $ranking = $stmt->get_result()->fetch_assoc()['ranking'];
    $stmt->close();

    // Obter top jogadores
    $stmt = $conn->prepare("
        SELECT p.username, pp.stars_earned, pp.current_level
        FROM player_progress pp
        INNER JOIN players p ON pp.player_id = p.id
        ORDER BY pp.stars_earned DESC, pp.current_level DESC
        LIMIT 10
    ");
    $stmt->execute();
    $top_players = [];
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $top_players[] = $row;
    }
    $stmt->close();
    $conn->close();

    // Log de carregamento
    logActivity($player_id, 'LOAD_PROGRESS', "Progresso carregado");

    jsonResponse(true, 'Progresso carregado com sucesso', [
        'player' => [
            'id' => $player_id,
            'username' => $progress['username'],
            'email' => $progress['email'],
            'created_at' => $progress['created_at'],
            'last_login' => $progress['last_login']
        ],
        'progress' => [
            'level' => intval($progress['current_level']),
            'health' => intval($progress['health']),
            'stars' => intval($progress['stars_earned']),
            'apples' => intval($progress['apples_collected']),
            'wood' => intval($progress['wood_collected']),
            'completed_missions' => $progress['completed_missions'] ?? ''
        ],
        'stats' => [
            'total_time' => intval($stats['total_time'] ?? 0),
            'monsters_avoided' => intval($stats['total_monsters'] ?? 0),
            'items_collected' => intval($stats['total_items'] ?? 0),
            'deaths' => intval($stats['total_deaths'] ?? 0),
            'sessions' => intval($stats['total_sessions'] ?? 0)
        ],
        'ranking' => $ranking,
        'top_players' => $top_players
    ]);

} catch (Exception $e) {
    error_log("Erro em load.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao carregar progresso');
}
?>