<?php
require_once 'config.php';

// Verificar se usuário está logado
if (!isLoggedIn()) {
    jsonResponse(false, 'Não autenticado');
}

// Verificar se é requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Método não permitido');
}

try {
    $player_id = $_SESSION['player_id'];
    $conn = getDBConnection();
    
    if (!$conn) {
        jsonResponse(false, 'Erro ao conectar ao banco de dados');
    }

    // Obter dados do JSON
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);

    if (!$data) {
        jsonResponse(false, 'Dados inválidos');
    }

    // Validar dados
    $health = isset($data['health']) ? intval($data['health']) : 100;
    $stars = isset($data['stars']) ? intval($data['stars']) : 0;
    $level = isset($data['level']) ? intval($data['level']) : 1;
    $apples = isset($data['apples']) ? intval($data['apples']) : 0;
    $wood = isset($data['wood']) ? intval($data['wood']) : 0;
    $mission = isset($data['mission']) ? intval($data['mission']) : 1;
    $deaths = isset($data['deaths']) ? intval($data['deaths']) : 0;
    $monsters_avoided = isset($data['monsters_avoided']) ? intval($data['monsters_avoided']) : 0;
    $items_collected = isset($data['items_collected']) ? intval($data['items_collected']) : 0;
    $time_played = isset($data['time_played']) ? intval($data['time_played']) : 0;

    // Garantir valores válidos
    $health = max(0, min(100, $health));
    $stars = max(0, $stars);
    $level = max(1, $level);

    // Verificar se jogador existe no player_progress
    $stmt = $conn->prepare("SELECT id FROM player_progress WHERE player_id = ?");
    $stmt->bind_param("i", $player_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        // Criar registro se não existir
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO player_progress (player_id, current_level, health, stars_earned, apples_collected, wood_collected) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiiiii", $player_id, $level, $health, $stars, $apples, $wood);
        $stmt->execute();
    } else {
        // Atualizar progresso existente
        $stmt->close();
        $stmt = $conn->prepare("
            UPDATE player_progress 
            SET current_level = ?, 
                health = ?, 
                stars_earned = ?, 
                apples_collected = ?, 
                wood_collected = ?,
                updated_at = NOW()
            WHERE player_id = ?
        ");
        $stmt->bind_param("iiiiii", $level, $health, $stars, $apples, $wood, $player_id);
        $stmt->execute();
    }
    $stmt->close();

    // Atualizar estatísticas do jogo
    $stmt = $conn->prepare("
        INSERT INTO game_stats (player_id, level, time_played, monsters_avoided, items_collected, deaths, game_date)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
        time_played = time_played + VALUES(time_played),
        monsters_avoided = monsters_avoided + VALUES(monsters_avoided),
        items_collected = items_collected + VALUES(items_collected),
        deaths = deaths + VALUES(deaths)
    ");
    $stmt->bind_param("iiiii", $player_id, $level, $time_played, $monsters_avoided, $items_collected, $deaths);
    $stmt->execute();
    $stmt->close();

    // Log da atividade
    logActivity($player_id, 'SAVE_PROGRESS', "Level: $level, Stars: $stars, Health: $health");

    $conn->close();

    jsonResponse(true, 'Progresso salvo com sucesso!', [
        'saved_at' => date('Y-m-d H:i:s'),
        'level' => $level,
        'stars' => $stars,
        'health' => $health
    ]);

} catch (Exception $e) {
    error_log("Erro em save.php: " . $e->getMessage());
    jsonResponse(false, 'Erro ao salvar progresso');
}
?>