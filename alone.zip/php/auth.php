<?php
// INICIAR BUFFER DE SAÍDA para capturar qualquer output acidental
ob_start();

// DESATIVAR EXIBIÇÃO DE ERROS (não enviar HTML para o navegador)
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// INICIAR SESSÃO
if (session_status() === PHP_SESSION_NONE) {
    $cookieParams = session_get_cookie_params();
    session_set_cookie_params([
        'lifetime' => $cookieParams['lifetime'],
        'path' => $cookieParams['path'],
        'domain' => $cookieParams['domain'],
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// HEADERS CORS (devem vir ANTES de qualquer output)
header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? '*'));
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Se for requisição OPTIONS (preflight), sair imediatamente
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// CONFIGURAÇÕES DO BANCO
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'alone_game');

/**
 * Resposta JSON padronizada
 */
function jsonResponse($success, $message = '', $data = []) {
    // Limpar qualquer output anterior
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    http_response_code($success ? 200 : 400);
    
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data,
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Conexão com o banco
 */
function getDBConnection() {
    try {
        $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            error_log("Erro MySQL: " . $conn->connect_error);
            return null;
        }
        
        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (Exception $e) {
        error_log("Exceção: " . $e->getMessage());
        return null;
    }
}

/**
 * Sanitizar input
 */
function sanitizeInput($data) {
    return htmlspecialchars(trim($data ?? ''), ENT_QUOTES, 'UTF-8');
}

// Verificar se é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Método não permitido. Use POST.');
}

// Obter ação
$action = $_POST['action'] ?? '';

// Debug no log (não aparece para o usuário)
error_log("AÇÃO: $action | POST: " . json_encode($_POST));

try {
    $conn = getDBConnection();
    if (!$conn) {
        jsonResponse(false, 'Erro: não foi possível conectar ao banco de dados. Verifique se o MySQL está rodando.');
    }

    switch ($action) {
        
        // REGISTRO
        case 'register':
            $username = sanitizeInput($_POST['username'] ?? '');
            $email = sanitizeInput($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? $_POST['password_confirmation'] ?? '';

            // Validar
            if (empty($username) || empty($email) || empty($password)) {
                jsonResponse(false, 'Todos os campos são obrigatórios.');
            }

            if ($password !== $confirm_password) {
                jsonResponse(false, 'As senhas não coincidem.');
            }

            if (strlen($password) < 6) {
                jsonResponse(false, 'A senha deve ter pelo menos 6 caracteres.');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                jsonResponse(false, 'Email inválido.');
            }

            if (strlen($username) < 3 || strlen($username) > 20) {
                jsonResponse(false, 'Usuário deve ter 3-20 caracteres.');
            }

            // Verificar duplicidade
            $stmt = $conn->prepare("SELECT id FROM players WHERE username = ? OR email = ?");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stmt->close();
                $conn->close();
                jsonResponse(false, 'Usuário ou email já cadastrado.');
            }
            $stmt->close();

            // Criptografar senha
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            if (!$hashed_password) {
                jsonResponse(false, 'Erro ao processar senha.');
            }

            // Inserir jogador
            $stmt = $conn->prepare("INSERT INTO players (username, email, password, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->bind_param("sss", $username, $email, $hashed_password);
            
            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();
                $conn->close();
                jsonResponse(false, "Erro ao registrar: $error");
            }

            $player_id = $conn->insert_id;
            $stmt->close();

            // Criar progresso
            $stmt = $conn->prepare("INSERT INTO player_progress (player_id, current_level, health, stars_earned) VALUES (?, 1, 100, 0)");
            $stmt->bind_param("i", $player_id);
            $stmt->execute();
            $stmt->close();

            // Logar automaticamente
            $_SESSION['player_id'] = $player_id;
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            $_SESSION['logged_in'] = true;

            error_log("REGISTRO OK - Player ID: $player_id");

            $conn->close();

            jsonResponse(true, 'Registro realizado com sucesso!', [
                'player_id' => $player_id,
                'username' => $username,
                'redirect' => 'game.html'
            ]);
            break;

        // LOGIN
        case 'login':
            $username = sanitizeInput($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($username) || empty($password)) {
                jsonResponse(false, 'Usuário e senha são obrigatórios.');
            }

            // Buscar jogador
            $stmt = $conn->prepare("SELECT id, username, email, password FROM players WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 0) {
                $stmt->close();
                $conn->close();
                jsonResponse(false, 'Usuário não encontrado.');
            }

            $player = $result->fetch_assoc();
            $stmt->close();

            // Verificar senha
            if (!password_verify($password, $player['password'])) {
                $conn->close();
                jsonResponse(false, 'Senha incorreta.');
            }

            // Regenerar sessão
            session_regenerate_id(true);

            // Armazenar na sessão
            $_SESSION['player_id'] = $player['id'];
            $_SESSION['username'] = $player['username'];
            $_SESSION['email'] = $player['email'];
            $_SESSION['logged_in'] = true;

            error_log("LOGIN OK - Player ID: {$player['id']}");

            // Obter progresso
            $stmt = $conn->prepare("SELECT current_level, health, stars_earned, apples_collected, wood_collected FROM player_progress WHERE player_id = ?");
            $stmt->bind_param("i", $player['id']);
            $stmt->execute();
            $progress_result = $stmt->get_result();
            $progress = $progress_result->fetch_assoc();
            $stmt->close();
            $conn->close();

            if (!$progress) {
                $progress = [
                    'current_level' => 1,
                    'health' => 100,
                    'stars_earned' => 0,
                    'apples_collected' => 0,
                    'wood_collected' => 0
                ];
            }

            jsonResponse(true, 'Login realizado com sucesso!', [
                'player_id' => $player['id'],
                'username' => $player['username'],
                'email' => $player['email'],
                'progress' => [
                    'level' => intval($progress['current_level']),
                    'health' => intval($progress['health']),
                    'stars' => intval($progress['stars_earned']),
                    'apples' => intval($progress['apples_collected']),
                    'wood' => intval($progress['wood_collected'])
                ],
                'redirect' => 'game.html'
            ]);
            break;

        // LOGOUT
        case 'logout':
            $player_id = $_SESSION['player_id'] ?? null;
            $_SESSION = [];
            session_destroy();
            
            jsonResponse(true, 'Logout realizado.', [
                'redirect' => 'index.html'
            ]);
            break;

        // VERIFICAR SESSÃO
        case 'check_session':
            if (isset($_SESSION['player_id']) && !empty($_SESSION['player_id'])) {
                jsonResponse(true, 'Sessão ativa', [
                    'player_id' => $_SESSION['player_id'],
                    'username' => $_SESSION['username'] ?? 'Usuário',
                    'email' => $_SESSION['email'] ?? ''
                ]);
            } else {
                session_destroy();
                jsonResponse(false, 'Sessão expirada.');
            }
            break;

        default:
            jsonResponse(false, "Ação inválida: $action");
            break;
    }

    $conn->close();

} catch (Exception $e) {
    error_log("EXCEÇÃO: " . $e->getMessage());
    
    // Garantir que NUNCA retorne HTML
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Erro interno do servidor.',
        'error' => $e->getMessage(),
        'debug' => 'Verifique os logs do PHP para detalhes.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
?>